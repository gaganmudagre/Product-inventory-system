package project;
//Main.java

//Main.java

//Main.java

import java.util.Scanner;

public class Main
{
 public static void main(String args[]) throws Exception
 {
     Scanner sc = new Scanner(System.in);

     WarehouseOperations wo =
     new WarehouseOperations();

     while(true)
     {
         System.out.println("\n======================================================");

         System.out.println(" SMART WAREHOUSE INVENTORY AND ORDER MANAGEMENT SYSTEM ");

         System.out.println("======================================================");

         System.out.println("\n1. Customer Login");
         System.out.println("2. Warehouse Incharge Login");
         System.out.println("3. Exit");

         System.out.println("\nEnter Choice:");

         int choice = sc.nextInt();

         switch(choice)
         {
             case 1:
                 wo.customerLogin();
                 break;

             case 2:
                 wo.adminLogin();
                 break;

             case 3:
                 System.exit(0);

             default:
                 System.out.println("Invalid Choice");
         }
     }
 }
}
