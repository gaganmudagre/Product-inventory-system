package project;

//WarehouseOperations.java

import java.sql.*;
import java.util.Scanner;

public class WarehouseOperations
{
 Scanner sc = new Scanner(System.in);

 // ================= ADMIN LOGIN =================

//================= ADMIN LOGIN =================

public void adminLogin() throws Exception
{
  sc.nextLine();

  System.out.println("\n========= WAREHOUSE INCHARGE LOGIN =========");

  System.out.println("Enter Username:");
  String username = sc.nextLine();

  System.out.print("Enter Password: ");

  String password = "";

  while(true)
  {
      char ch = (char)System.in.read();

      if(ch == '\n' || ch == '\r')
      {
          break;
      }

      password += ch;

      System.out.print("*");
  }

  System.out.println();

  if(username.equals("admin") &&
     password.equals("admin123"))
  {
      System.out.println("\nLogin Successful");

      adminMenu();
  }

  else
  {
      System.out.println("Invalid Login");
  }
}
 // ================= ADMIN MENU =================

 public void adminMenu()
 {
     while(true)
     {
         System.out.println("\n========= WAREHOUSE INCHARGE MENU =========");

         System.out.println("1. Add Inventory");
         System.out.println("2. Add Product");
         System.out.println("3. Add Customer");
         System.out.println("4. Display Products");
         System.out.println("5. Delete Product ");        
         System.out.println("6. View Order By Order ID");
         System.out.println("7. Logout");

         System.out.println("\nEnter Choice:");

         int choice = sc.nextInt();

         switch(choice)
         {
             case 1:
                 addInventory();
                 break;

             case 2:
                 addProduct();
                 break;

             case 3:
                 addCustomer();
                 break;

             case 4:
                 viewProducts();
                 break;

             case 5:
            	    deleteProduct();
            	    break;

            	case 6:
            	    viewOrderById();
            	    break;

            	case 7:
            	    return;

             default:
                 System.out.println("Invalid Choice");
         }
     }
 }

 // ================= ADD INVENTORY =================

 public void addInventory()
 {
     try
     {
         Connection con = DBConnection.getConnection();

         System.out.println("Enter Inventory ID:");
         int id = sc.nextInt();
         sc.nextLine();

         System.out.println("Enter Inventory Name:");
         String name = sc.nextLine();

         System.out.println("Enter Location:");
         String location = sc.nextLine();

         String query =
         "insert into inventory values(?,?,?)";

         PreparedStatement pst =
         con.prepareStatement(query);

         pst.setInt(1, id);
         pst.setString(2, name);
         pst.setString(3, location);

         pst.executeUpdate();

         System.out.println("\nInventory Added Successfully");

         con.close();
     }

     catch(Exception e)
     {
         System.out.println(e);
     }
 }

 // ================= ADD PRODUCT =================

 public void addProduct()
 {
     try
     {
         Connection con = DBConnection.getConnection();

         System.out.println("Enter Product ID:");
         int id = sc.nextInt();
         sc.nextLine();

         System.out.println("Enter Product Name:");
         String name = sc.nextLine();

         System.out.println("Enter Brand:");
         String brand = sc.nextLine();

         System.out.println("Enter Price:");
         double price = sc.nextDouble();

         System.out.println("Enter Quantity:");
         int quantity = sc.nextInt();

         System.out.println("Enter Inventory ID:");
         int inventoryId = sc.nextInt();

         String query =
         "insert into product values(?,?,?,?,?,?)";

         PreparedStatement pst =
         con.prepareStatement(query);

         pst.setInt(1, id);
         pst.setString(2, name);
         pst.setString(3, brand);
         pst.setDouble(4, price);
         pst.setInt(5, quantity);
         pst.setInt(6, inventoryId);

         pst.executeUpdate();

         System.out.println("\nProduct Added Successfully");

         con.close();
     }

     catch(Exception e)
     {
         System.out.println(e);
     }
 }

 // ================= ADD CUSTOMER =================

 public void addCustomer()
 {
     try
     {
         Connection con = DBConnection.getConnection();

         System.out.println("Enter Customer ID:");
         int id = sc.nextInt();
         sc.nextLine();

         System.out.println("Enter Customer Name:");
         String name = sc.nextLine();

         System.out.println("Enter Phone:");
         String phone = sc.nextLine();

         System.out.println("Enter City:");
         String city = sc.nextLine();

         System.out.println("Enter Password:");
         String password = sc.nextLine();

         String query =
         "insert into customer values(?,?,?,?,?)";

         PreparedStatement pst =
         con.prepareStatement(query);

         pst.setInt(1, id);
         pst.setString(2, name);
         pst.setString(3, phone);
         pst.setString(4, city);
         pst.setString(5, password);

         pst.executeUpdate();

         System.out.println("\nCustomer Added Successfully");

         con.close();
     }

     catch(Exception e)
     {
         System.out.println(e);
     }
 }

 // ================= DISPLAY PRODUCTS =================

 public void viewProducts()
 {
     try
     {
         Connection con = DBConnection.getConnection();

         String query =
         "select * from product";

         Statement st =
         con.createStatement();

         ResultSet rs =
         st.executeQuery(query);

         System.out.println("\n===================================================================================================");

         System.out.printf("%-10s %-30s %-20s %-15s %-10s\n",
         "ID",
         "PRODUCT NAME",
         "BRAND",
         "PRICE",
         "QUANTITY");

         System.out.println("===================================================================================================");

         while(rs.next())
         {
             System.out.printf("%-10d %-30s %-20s %-15.2f %-10d\n",

             rs.getInt("product_id"),

             rs.getString("product_name"),

             rs.getString("brand"),

             rs.getDouble("price"),

             rs.getInt("quantity"));
         }

         System.out.println("===================================================================================================");

         con.close();
     }

     catch(Exception e)
     {
         System.out.println(e);
     }
 }

//================= DELETE PRODUCT =================

 public void deleteProduct()
 {
     try
     {
         Connection con = DBConnection.getConnection();

         viewProducts();

         System.out.print("\nEnter Product ID To Delete: ");
         int productId = sc.nextInt();

         // CHECK IF PRODUCT EXISTS IN ORDER_DETAILS
         String checkQuery =
         "select * from order_details where product_id=?";

         PreparedStatement checkStmt =
         con.prepareStatement(checkQuery);

         checkStmt.setInt(1, productId);

         ResultSet rs = checkStmt.executeQuery();

         if(rs.next())
         {
             System.out.println("\nCannot delete this product.");
             System.out.println("It is already used in orders.");

             return;
         }

         // DELETE PRODUCT
         String deleteQuery =
         "delete from product where product_id=?";

         PreparedStatement pst =
         con.prepareStatement(deleteQuery);

         pst.setInt(1, productId);

         int rows = pst.executeUpdate();

         if(rows > 0)
         {
             System.out.println("\nProduct Deleted Successfully");
         }
         else
         {
             System.out.println("\nProduct Not Found");
         }

         con.close();
     }
     catch(Exception e)
     {
         System.out.println(e);
     }
 }
 // ================= VIEW ORDER BY ID =================

 public void viewOrderById()
 {
     try
     {
         Connection con = DBConnection.getConnection();

         System.out.println("Enter Order ID:");
         int orderId = sc.nextInt();

         String query =
         "select o.order_id, c.customer_name, p.product_name, od.quantity_ordered, od.subtotal, o.order_date " +
         "from orders o " +
         "join customer c on o.customer_id = c.customer_id " +
         "join order_details od on o.order_id = od.order_id " +
         "join product p on od.product_id = p.product_id " +
         "where o.order_id=?";

         PreparedStatement pst =
         con.prepareStatement(query);

         pst.setInt(1, orderId);

         ResultSet rs =
         pst.executeQuery();

         boolean found = false;

         System.out.println("\n================ ORDER DETAILS ================\n");

         while(rs.next())
         {
             found = true;

             System.out.println("Order ID      : " + rs.getInt(1));
             System.out.println("Customer Name : " + rs.getString(2));
             System.out.println("Product Name  : " + rs.getString(3));
             System.out.println("Quantity      : " + rs.getInt(4));
             System.out.println("Subtotal      : " + rs.getDouble(5));
             System.out.println("Order Date    : " + rs.getDate(6));

             System.out.println("-----------------------------------------------");
         }

         if(found == false)
         {
             System.out.println("Order Not Found");
         }

         con.close();
     }

     catch(Exception e)
     {
         System.out.println(e);
     }
 }

 // ================= CUSTOMER LOGIN =================

//================= CUSTOMER LOGIN =================

public void customerLogin() throws Exception
{
  try
  {
      sc.nextLine();

      Connection con = DBConnection.getConnection();

      System.out.println("\n========= CUSTOMER LOGIN =========");

      System.out.println("Enter Phone Number:");
      String phone = sc.nextLine();

      System.out.print("Enter Password: ");

      String password = "";

      while(true)
      {
          char ch = (char)System.in.read();

          if(ch == '\n' || ch == '\r')
          {
              break;
          }

          password += ch;

          System.out.print("*");
      }

      System.out.println();

      String query =
      "select * from customer where phone=? and password=?";

      PreparedStatement pst =
      con.prepareStatement(query);

      pst.setString(1, phone);
      pst.setString(2, password);

      ResultSet rs =
      pst.executeQuery();

      if(rs.next())
      {
          int customerId =
          rs.getInt("customer_id");

          System.out.println("\nLogin Successful");

          customerMenu(customerId);
      }

      else
      {
          System.out.println("Invalid Login");
      }

      con.close();
  }

  catch(Exception e)
  {
      System.out.println(e);
  }
}
 // ================= CUSTOMER MENU =================

 public void customerMenu(int customerId)
 {
     while(true)
     {
         System.out.println("\n========= CUSTOMER MENU =========");

         System.out.println("1. View Available Products");
         System.out.println("2. Place New Order");
         System.out.println("3. View My Orders");
         System.out.println("4. View My Order Details");
         System.out.println("5. Logout");

         System.out.println("\nEnter Choice:");

         int choice = sc.nextInt();

         switch(choice)
         {
             case 1:
                 viewProducts();
                 break;

             case 2:
                 placeOrder(customerId);
                 break;

             case 3:
                 viewMyOrders(customerId);
                 break;

             case 4:
                 viewMyOrderDetails(customerId);
                 break;

             case 5:
                 return;

             default:
                 System.out.println("Invalid Choice");
         }
     }
 }

 // ================= PLACE ORDER =================

 public void placeOrder(int customerId)
 {
     try
     {
         Connection con = DBConnection.getConnection();

         viewProducts();

         int orderId = 1019;

         String idQuery =
         "select max(order_id) from orders";

         Statement st =
         con.createStatement();

         ResultSet rsId =
         st.executeQuery(idQuery);

         if(rsId.next() && rsId.getInt(1) != 0)
         {
             orderId =
             rsId.getInt(1) + 1;
         }

         int detailId = 5000;

         String detailQueryId =
         "select max(order_detail_id) from order_details";

         ResultSet rsDetail =
         st.executeQuery(detailQueryId);

         if(rsDetail.next() && rsDetail.getInt(1) != 0)
         {
             detailId =
             rsDetail.getInt(1) + 1;
         }

         System.out.println("\nGenerated Order ID: " + orderId);

         System.out.println("Enter Product ID:");
         int productId = sc.nextInt();

         System.out.println("Enter Quantity:");
         int quantity = sc.nextInt();

         String query =
         "select * from product where product_id=?";

         PreparedStatement pst =
         con.prepareStatement(query);

         pst.setInt(1, productId);

         ResultSet rs =
         pst.executeQuery();

         if(rs.next())
         {
             int stock =
             rs.getInt("quantity");

             String productName =
             rs.getString("product_name");

             String brand =
             rs.getString("brand");

             double price =
             rs.getDouble("price");

             if(stock >= quantity)
             {
                 double total =
                 quantity * price;

                 String orderQuery =
                 "insert into orders values(?,?,?,?,?)";

                 PreparedStatement pst2 =
                 con.prepareStatement(orderQuery);

                 pst2.setInt(1, orderId);

                 pst2.setInt(2, customerId);

                 pst2.setDate(
                 3,
                 new java.sql.Date(
                 System.currentTimeMillis())
                 );

                 pst2.setString(4, "Dispatched");

                 pst2.setDouble(5, total);

                 pst2.executeUpdate();

                 String detailQuery =
                 "insert into order_details values(?,?,?,?,?)";

                 PreparedStatement pst3 =
                 con.prepareStatement(detailQuery);

                 pst3.setInt(1, detailId);
                 pst3.setInt(2, orderId);
                 pst3.setInt(3, productId);
                 pst3.setInt(4, quantity);
                 pst3.setDouble(5, total);

                 pst3.executeUpdate();

                 int newStock =
                 stock - quantity;

                 String updateQuery =
                 "update product set quantity=? where product_id=?";

                 PreparedStatement pst4 =
                 con.prepareStatement(updateQuery);

                 pst4.setInt(1, newStock);
                 pst4.setInt(2, productId);

                 pst4.executeUpdate();

                 // ================= BILL =================

                 System.out.println("\n========================================================");

                 System.out.println("                  CUSTOMER BILL");

                 System.out.println("========================================================");

                 System.out.println("Order ID      : " + orderId);

                 System.out.println("Customer ID   : " + customerId);

                 System.out.println("Date          : " +
                 new java.sql.Date(System.currentTimeMillis()));

                 System.out.println("--------------------------------------------------------");

                 System.out.println("Product Name  : " + productName);

                 System.out.println("Brand         : " + brand);

                 System.out.println("Price         : " + price);

                 System.out.println("Quantity      : " + quantity);

                 System.out.println("--------------------------------------------------------");

                 System.out.println("Total Amount  : " + total);

                 System.out.println("Order Status  : Dispatched");

                 System.out.println("========================================================");

                 System.out.println("        THANK YOU FOR SHOPPING WITH US");

                 System.out.println("========================================================");

                 System.out.println("\nRemaining Stock: " + newStock);
             }

             else
             {
                 System.out.println("Insufficient Stock");
             }
         }

         else
         {
             System.out.println("Product Not Found");
         }

         con.close();
     }

     catch(Exception e)
     {
         System.out.println(e);
     }
 }

 // ================= VIEW MY ORDERS =================

 public void viewMyOrders(int customerId)
 {
     try
     {
         Connection con = DBConnection.getConnection();

         String query =
         "select * from orders where customer_id=?";

         PreparedStatement pst =
         con.prepareStatement(query);

         pst.setInt(1, customerId);

         ResultSet rs =
         pst.executeQuery();

         boolean found = false;

         System.out.println("\n================ MY ORDERS ================\n");

         while(rs.next())
         {
             found = true;

             System.out.println(
                 "Order ID : " +
                 rs.getInt("order_id") +

                 " | Date : " +
                 rs.getDate("order_date") +

                 " | Status : " +
                 rs.getString("order_status") +

                 " | Total : " +
                 rs.getDouble("total_amount")
             );
         }

         if(found == false)
         {
             System.out.println("No Orders Yet");
         }

         con.close();
     }

     catch(Exception e)
     {
         System.out.println(e);
     }
 }

 // ================= VIEW ORDER DETAILS =================

 public void viewMyOrderDetails(int customerId)
 {
     try
     {
         Connection con = DBConnection.getConnection();

         String query =
         "select od.order_id, p.product_name, od.quantity_ordered, od.subtotal " +
         "from order_details od " +
         "join orders o on od.order_id = o.order_id " +
         "join product p on od.product_id = p.product_id " +
         "where o.customer_id=?";

         PreparedStatement pst =
         con.prepareStatement(query);

         pst.setInt(1, customerId);

         ResultSet rs =
         pst.executeQuery();

         boolean found = false;

         System.out.println("\n================ MY ORDER DETAILS ================\n");

         while(rs.next())
         {
             found = true;

             System.out.println(
                 "Order ID : " +
                 rs.getInt(1) +

                 " | Product : " +
                 rs.getString(2) +

                 " | Quantity : " +
                 rs.getInt(3) +

                 " | Subtotal : " +
                 rs.getDouble(4)
             );
         }

         if(found == false)
         {
             System.out.println("No Order Details Yet");
         }

         con.close();
     }

     catch(Exception e)
     {
         System.out.println(e);
     }
 }
}